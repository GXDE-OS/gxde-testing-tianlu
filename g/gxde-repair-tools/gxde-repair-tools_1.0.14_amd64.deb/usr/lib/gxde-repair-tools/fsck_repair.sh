#!/bin/sh

fsck -y $1
