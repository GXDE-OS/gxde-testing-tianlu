#!/bin/sh

fsck -v -n $1
