#!/usr/bin/env python3

"""
Init file for the package.
"""

from .__main__ import _main

__all__ = ["_main"]
