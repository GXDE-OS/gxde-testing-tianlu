"""
__main__ for edge_tts.
"""

from .util import main

if __name__ == "__main__":
    main()
